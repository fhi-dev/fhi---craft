fx_version 'cerulean'
game 'gta5'

author 'fhi-dev'
description 'fhi'
version '1.1.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/styles.css',
    'html/app.js',
    'html/img/*.png'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}