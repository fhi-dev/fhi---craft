let recipes = [
  {
    name: "مسدس",
    code: "weapon_pistol_mk2",
    icon: "img/weapon_pistol_mk2.png",
    items: [
      { name: "iron", count: 20, icon: "img/iron.png" },
      { name: "copper", count: 24, icon: "img/copper.png" }
    ]
  },
  {
    name: "مسدس ثقيل",
    code: "weapon_heavypistol",
    icon: "img/weapon_heavypistol.png",
    items: [
      { name: "iron", count: 45, icon: "img/iron.png" },
      { name: "copper", count: 31, icon: "img/copper.png" },
      { name: "metalscrap", count: 41, icon: "img/metalscrap.png" }
    ]
  },
  // هنا تضيف أيتم جديد:
  {
    name: "كلبشه",
    code: "handcuffs", // الكود كما هو في قاعدة بياناتك
    icon: "img/handcuffs.png",
    items: [
      { name: "iron", count: 2, icon: "img/iron.png" },
      { name: "copper", count: 8, icon: "img/copper.png" }
    ]
  }
];

let selectedRecipe = null;

function renderRecipeList(filter = "") {
  const list = document.getElementById("recipeList");
  list.innerHTML = "";
  recipes
    .filter(r => r.name.includes(filter))
    .forEach(recipe => {
      const div = document.createElement("div");
      div.className = "recipe-item" + (selectedRecipe && selectedRecipe.code === recipe.code ? " selected" : "");
      div.onclick = () => selectRecipe(recipe.code);

      div.innerHTML = `
        <img src="${recipe.icon}" style="width:34px;height:34px;border-radius:7px;margin-left:10px;">
        <span class="recipe-name">${recipe.name}</span>
        <span class="recipe-items">
          ${recipe.items.map(i => `<img src="${i.icon}" title="${i.name} x${i.count}" class="recipe-item-icon"/>`).join('')}
        </span>
      `;
      list.appendChild(div);
    });
}

function selectRecipe(code) {
  selectedRecipe = recipes.find(r => r.code === code);
  renderRecipeList(document.getElementById("searchInput").value);
  renderRecipeDetails();
}

function renderRecipeDetails() {
  const details = document.getElementById("recipeDetails");
  if (!selectedRecipe) {
    details.innerHTML = "";
    return;
  }
  details.innerHTML = `
    <div class="crafting-details-title">${selectedRecipe.name}</div>
    <div class="crafting-details-list">
      ${selectedRecipe.items.map(i =>
        `<span><img src="${i.icon}" style="width:18px;vertical-align:middle;margin-left:4px"> ${i.name} ×${i.count}</span>`
      ).join('')}
    </div>
    <button id="craftButton">بدء التصنيع</button>
  `;
  document.getElementById("craftButton").onclick = () => {
    fetch(`https://${GetParentResourceName()}/craftItem`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: selectedRecipe.code })
    });
  };
}

document.getElementById("searchInput").addEventListener("input", function() {
  renderRecipeList(this.value);
});

window.addEventListener("message", function(event) {
  if (event.data.showCrafting) {
    document.getElementById("crafting-container").style.display = "block";
    renderRecipeList();
    document.getElementById("recipeDetails").innerHTML = "";
    selectedRecipe = null;
  } else if (event.data.hideCrafting) {
    document.getElementById("crafting-container").style.display = "none";
  }
  if (event.data.showProgress) {
    showProgress(event.data.duration || 10000);
  }
  if (event.data.hideProgress) {
    hideProgress();
  }
});

// إغلاق بالـ ESC
window.addEventListener("keydown", function(e){
  if (e.key === "Escape"){
    document.getElementById("crafting-container").style.display = "none";
    fetch(`https://${GetParentResourceName()}/closeCrafting`);
  }
});

renderRecipeList();

/// --- Progress bar functions ---
let progressInterval = null;
function showProgress(duration) {
  document.getElementById("progress").style.display = "flex";
  let bar = document.getElementById("progress-bar");
  let percent = 0;
  bar.style.width = "0%";
  let start = Date.now();
  progressInterval = setInterval(() => {
    let elapsed = Date.now() - start;
    percent = Math.min(100, Math.round((elapsed / duration) * 100));
    bar.style.width = percent + "%";
    if (percent >= 100) {
      clearInterval(progressInterval);
      setTimeout(()=>hideProgress(),500);
    }
  }, 100);
}
function hideProgress() {
  document.getElementById("progress").style.display = "none";
  if (progressInterval) clearInterval(progressInterval);
}