local QBCore = exports['qb-core']:GetCoreObject()

local recipes = {
    ["weapon_pistol_mk2"] = {
        items = {
            ["iron"] = 1,
            ["copper"] = 1
        },
        time = 7000
    },
    ["weapon_heavypistol"] = {
        items = {
            ["iron"] = 1,
            ["copper"] = 1,
            ["metalscrap"] = 1
        },
        time = 10000
    },
    ["handcuffs"] = { 
        items = {
            ["iron"] = 2,
            ["copper"] = 8
        },
        time = 12000 -- وقت التصنيع بالمللي ثانية (12 ثانية)
    }
}
local function canCraft(source, recipe)
    local Player = QBCore.Functions.GetPlayer(source)
    for item, count in pairs(recipe.items) do
        local invItem = Player.Functions.GetItemByName(item)
        if not invItem or invItem.amount < count then
            return false
        end
    end
    return true
end

local function removeItems(source, recipe)
    local Player = QBCore.Functions.GetPlayer(source)
    for item, count in pairs(recipe.items) do
        Player.Functions.RemoveItem(item, count)
    end
end

RegisterNetEvent('custom_crafting:craft', function(recipeName)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local recipe = recipes[recipeName]
    if recipe and canCraft(src, recipe) then
        removeItems(src, recipe)
        TriggerClientEvent('QBCore:Notify', src, "جاري التصنيع ... يرجى الانتظار", "primary")
        TriggerClientEvent('custom_crafting:craftingProgress', src, recipe.time or 10000)
        SetTimeout(recipe.time or 10000, function()
            Player.Functions.AddItem(recipeName, 1)
            TriggerClientEvent('custom_crafting:hideProgress', src)
            TriggerClientEvent('QBCore:Notify', src, "تم التصنيع بنجاح!", "success")
        end)
    else
        TriggerClientEvent('QBCore:Notify', src, "لا تملك العناصر المطلوبة!", "error")
    end
end)