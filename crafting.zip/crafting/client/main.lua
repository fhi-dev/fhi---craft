local tableCoords = vector3(5.4, -622.59, 14.73)-- عدل الإحداثيات حسب مكان طاولتك
local tableHeading = 90.0
local objName = "gr_prop_gr_bench_02b" -- اسم مجسم الطاولة

CreateThread(function()
    RequestModel(objName)
    while not HasModelLoaded(objName) do Wait(0) end
    local obj = CreateObject(objName, tableCoords.x, tableCoords.y, tableCoords.z, false, false, false)
    SetEntityHeading(obj, tableHeading)
    FreezeEntityPosition(obj, true)
    exports['qb-target']:AddTargetEntity(obj, {
        options = {
            {
                icon = "fas fa-hammer",
                label = "فتح طاولة التصنيع",
                action = function()
                    SetNuiFocus(true, true)
                    SendNUIMessage({ showCrafting = true })
                end
            }
        },
        distance = 2.0
    })
end)

RegisterNUICallback('craftItem', function(data, cb)
    TriggerServerEvent('custom_crafting:craft', data.code)
    cb('ok')
end)

RegisterNUICallback('closeCrafting', function(_, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ hideCrafting = true })
    cb('ok')
end)

RegisterNetEvent('custom_crafting:craftingProgress', function(duration)
    SendNUIMessage({ showProgress = true, duration = duration })
end)

RegisterNetEvent('custom_crafting:hideProgress', function()
    SendNUIMessage({ hideProgress = true })
end)

RegisterCommand('closeCrafting', function()
    SetNuiFocus(false, false)
    SendNUIMessage({ hideCrafting = true })
end, false)